import json
import requests
import os

print('Loading function')

def lambda_handler(event, context):

    env = os.environ['ENV']
    if (env != "production"):
        url = "https://user-signup-api." + env + ".wifi.service.gov.uk:8443/user-signup/email-notification"
    else:
        url = "https://user-signup-api.wifi.service.gov.uk:8443/user-signup/email-notification"

    print(url)

    sns_message_payload = event["Records"][0]["Sns"]

    print('Message Posted')
    print(event["Records"][0]["Sns"])

    sns_message_headers = {
        "x-amz-sns-message-id": sns_message_payload['MessageId'],
        "x-amz-sns-message-type": sns_message_payload["Type"],
        "x-amz-sns-subscription-arn" : event["Records"][0]["EventSubscriptionArn"],
        "x-amz-sns-topic-arn" : sns_message_payload["TopicArn"]
    }

    try:
        r = requests.post(url = url, data = json.dumps(sns_message_payload), headers = sns_message_headers)
    except Exceptions as e:
        print(e)

    return
