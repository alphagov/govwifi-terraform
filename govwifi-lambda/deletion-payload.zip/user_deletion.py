import os

import pymysql.cursors

class UserDeletion():
  def delete_old_users(self):
    db = pymysql.connect(
      os.environ.get('DATABASE_HOST'),
      os.environ.get('DATABASE_USER'),
      os.environ.get('DATABASE_PASSWORD'),
      os.environ.get('DATABASE')
    )
    cursor = db.cursor()
    cursor.execute("SHOW DATABASES")
    return cursor.fetchall()